<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class EmpController extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper(array('url','form'));
        $this->load->model('empModel');
    }
    //All data of employee
    public function index(){
        $data = array();
        $data['emp_search'] = $this->input->get_post('emp_search');
        $data['dynamic_title'] = "All Employee Data";
        $this->load->library('pagination');
        $data['page_offset'] = $this->input->get_post('page_offset');
        $config['base_url'] = base_url()."index.php/EmpController/index/";
        $config['total_rows'] = $this->empModel->emp_count_records($data['emp_search']);
        $config['per_page'] = 3;
        $this->pagination->initialize($config);
        if($data['page_offset'] != NULL){
            $page_offset = $data['page_offset'];
        }else if($this->uri->segment(3)){
            $page_offset = ($this->uri->segment(3));
        }else{
            $page_offset = 1;
        }
        $data['page_offset'] = $page_offset;
        $data['emp_details'] = $this->empModel->emp_data_fetch($config["per_page"],$page_offset,$data['emp_search']);
        $data['pagination_link'] = $this->pagination->create_links();
        $this->load->view('header',$data);
        $this->load->view('EmpView',$data);
        $this->load->view('footer');
    }
    //Employee regitration form
    public function emp_reg(){
        $data = array();
        $data['dynamic_title'] = "New Employee Registration";
        $this->load->view('header',$data);
        $this->load->view('EmpAdd');
        $this->load->view('footer');
    }
    //Form data Save
    public function emp_reg_save(){
        $data = array();
        $data['emp_name'] = trim($this->input->post('empName'));
        $data['emp_password'] = md5(trim($this->input->post('empPassword')));
        $data['emp_mail'] = trim($this->input->post('empMail'));
        $data['emp_mobile'] = trim($this->input->post('empMobile'));
        if(!empty($this->input->post('empBirthdate'))){
            $dob = explode("-",$this->input->post('empBirthdate'));//date post pattern YYYY-mm-dd 
            $data['emp_birthdate'] = mktime(1,1,1,$dob[1],$dob[2],$dob[0]);
        }
        $data['emp_address'] = trim($this->input->post('empAddress'));
        $data['emp_city'] = trim($this->input->post('empCity'));
        $data['emp_gender'] = trim($this->input->post('empGender'));
        if(!empty($this->input->post('empLanguage'))){
            $data['emp_language'] = implode(',',$this->input->post('empLanguage'));
        }
        if(!empty($_FILES['empProfile']['name'])){
            $config['upload_path'] = 'assets/emp_profile/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = 3072; // 3MB;
            $config['max_width'] = 3000; 
            $config['max_height'] = 3000; 
            $config['file_name'] = $_FILES['empProfile']['name'];
            //Load upload library and initialize configuration
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            if($this->upload->do_upload('empProfile')){
                $uploadData = $this->upload->data();
                $picture = $uploadData['file_name'];
            }else{
                $picture = '';
            }
        }else{
            $picture = '';
        }
        $data['emp_profile'] = $picture;
        //Server side validation also we can do here
        $inserted_data = array(
            'emp_name'=>$data['emp_name'],
            'emp_password'=>$data['emp_password'],
            'emp_mail'=>$data['emp_mail'],
            'emp_mobile'=>$data['emp_mobile'],
            'emp_birthdate'=>$data['emp_birthdate'],
            'emp_address'=>$data['emp_address'],
            'emp_city'=>$data['emp_city'],
            'emp_gender'=>$data['emp_gender'],
            'emp_language'=>$data['emp_language'],
            'emp_profile'=>$data['emp_profile'],
            );
        $query = $this->empModel->emp_insert_data($inserted_data);
        if($query){
            $this->session->set_flashdata('msg', 'Data has been Inserted !!!'); 
        }else{
            $this->session->set_flashdata('msg', 'Oops ! Soemting went wrong , data was not Inserted !!!'); 
        }
        redirect('EmpController/emp_reg');
    }
    //Edit form
    public function emp_edit($emp_id,$page_offset){
        $data = array();
        $data['emp_details'] = $this->empModel->emp_single_fetch($emp_id);
        $data['dynamic_title'] = "Edit Employee Data";
        $data['page_offset'] = $page_offset;
        $this->load->view('header',$data);
        $this->load->view('empEdit',$data);
        $this->load->view('footer');
    }
    //Edit form save
    public function emp_edit_save(){
        $data = array();
        $emp_id = trim($this->input->post('empID'));
        $data['emp_name'] = trim($this->input->post('empName'));
        $data['emp_password'] = trim($this->input->post('empPassword'));
        $data['emp_mail'] = trim($this->input->post('empMail'));
        $data['emp_mobile'] = trim($this->input->post('empMobile'));
        if(!empty($this->input->post('empBirthdate'))){
            $dob = explode("-",$this->input->post('empBirthdate'));//date post pattern yyyy/mm/dd 
            $data['emp_birthdate'] = mktime(1,1,1,$dob[1],$dob[2],$dob[0]);
        }
        $data['emp_address'] = trim($this->input->post('empAddress'));
        $data['emp_city'] = trim($this->input->post('empCity'));
        $data['emp_gender'] = trim($this->input->post('empGender'));
        if(!empty($this->input->post('empLanguage'))){
            $data['emp_language'] = implode(',',$this->input->post('empLanguage'));
        }
        if(!empty($_FILES['empProfile']['name'])){
            $config['upload_path'] = 'assets/emp_profile/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = 3072; // 3MB;
            $config['max_width'] = 3000; 
            $config['max_height'] = 3000; 
            $config['file_name'] = $_FILES['empProfile']['name'];
            //Load upload library and initialize configuration
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            if($this->upload->do_upload('empProfile')){
                $uploadData = $this->upload->data();
                $picture = $uploadData['file_name'];
            }else{
                $picture = '';
            }
        }else{
            $picture = $this->input->post('old_profile');
        }
        $data['emp_profile'] = $picture;
        $data['page_offset'] = $this->input->post('page_offset');
        $updated_data = array(
            'emp_name'=>$data['emp_name'],
            'emp_password'=>$data['emp_password'],
            'emp_mail'=>$data['emp_mail'],
            'emp_mobile'=>$data['emp_mobile'],
            'emp_birthdate'=>$data['emp_birthdate'],
            'emp_address'=>$data['emp_address'],
            'emp_city'=>$data['emp_city'],
            'emp_gender'=>$data['emp_gender'],
            'emp_language'=>$data['emp_language'],
            'emp_profile'=>$data['emp_profile'],
            );
        $query = $this->empModel->emp_update_data($updated_data,$emp_id);
        if($query){
            $this->session->set_flashdata('msg', 'Data has been Updated !!!'); 
        }else{
            $this->session->set_flashdata('msg', 'Oops ! Soemting went wrong , data was not Updated !!!'); 
        }
        //redirect('EmpController/emp_edit/'.$emp_id.'/'.$data['page_offset']);
        redirect('EmpController/index/'.$data['page_offset']);
    }
    //Delete of employee
    public function emp_delete($emp_id,$page_offset){
        $query = $this->empModel->emp_delete_data($emp_id);
        if($query){
            $this->session->set_flashdata('msg', 'Data has been Deleted !!!'); 
        }else{
            $this->session->set_flashdata('msg', 'Oops ! Data not Deleted !!!'); 
        }
        redirect('EmpController/index/'.$page_offset);
    }
}// --- End of Class EmpController --- // 
?>