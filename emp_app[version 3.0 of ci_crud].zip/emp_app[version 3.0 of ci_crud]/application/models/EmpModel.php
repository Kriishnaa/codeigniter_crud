<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class EmpModel extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        $this->load->database(); 
    }
    //All employee data fetch
    public function emp_data_fetch($limit = NULL,$page_offset = NULL,$emp_search = NULL){
        if($limit != NULL || $page_offset != NULL){
            $this->db->limit($limit,$page_offset);
        }
        $this->db->where('emp_status','Y');
        if($emp_search != NULL){
            $this->db->like('emp_name',$emp_search);
        }
        $this->db->order_by('emp_name');
        $query = $this->db->get('emp_master');
        return $query->result_array(); 
    } 
    //Count nos of rows.
    public function emp_count_records($emp_search = NULL){
        $this->db->where('emp_status','Y');
        if($emp_search != NULL){
            $this->db->like('emp_name',$emp_search);
        }
        return $this->db->count_all_results('emp_master');
    }
    //Insert employee data
    public function emp_insert_data($data){
        $this->db->insert('emp_master',$data);
        return $this->db->insert_id() > 0 ? true : false;
    }
    //Fetch Single employee data
    public function emp_single_fetch($emp_id){
        $this->db->where('emp_id',$emp_id);
        $query = $this->db->get('emp_master');
        return $query->row_array(); 
    }
    //Update of employee data
    public function emp_update_data($data,$emp_id){
        $this->db->where('emp_id',$emp_id);
        $this->db->update('emp_master',$data);
        return $this->db->affected_rows() ? true : false;        
    }
    //Delete of employee data
    public function emp_delete_data($emp_id){
        $this->db->where('emp_id',$emp_id);
        $this->db->set('emp_status','N');
        $this->db->update('emp_master');
        return $this->db->affected_rows() ? true : false; 
    }
}// --- End of Class EmpModel ---// 
?>