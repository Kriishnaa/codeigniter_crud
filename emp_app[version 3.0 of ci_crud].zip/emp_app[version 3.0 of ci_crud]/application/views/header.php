<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Employee Registration Data</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
            <script src="<?php echo base_url('assets/js/jquery-3.3.1.min.js');?>"></script>
            <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
    </head>
    <body>
    <div class="text-center">
        <div class="alert alert-primary" role="alert">
            <h1><?php echo $dynamic_title; ?></h1>
        </div>
    </div>
    <div class="container">